# SHADOW SYSTEM V4
Versão com logo, splash, abas deslizáveis, câmera/galeria para shape e dieta, checkboxes de missões, dicas e missões bônus aleatórias por notificação ao longo do dia.
