plugins { id("com.android.application") }

android {
    namespace = "com.shadowsystem.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.shadowsystem.app.v5"
        minSdk = 23
        targetSdk = 35
        versionCode = 11
        versionName = "2.0.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
}

dependencies { implementation("androidx.core:core:1.15.0") }
