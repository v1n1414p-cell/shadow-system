package com.shadowsystem.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import androidx.core.content.FileProvider;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    SystemView view; SharedPreferences prefs; Uri cameraUri; File cameraFile;
    final int REQ_CAMERA=91;
    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("shadow",0); view=new SystemView(); setContentView(view);}

    void camera(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_CAMERA);return;}
        try{
            File dir=new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES),"evolucao"); if(!dir.exists())dir.mkdirs();
            String name="shape_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".jpg";
            cameraFile=new File(dir,name); cameraUri=FileProvider.getUriForFile(this,"com.shadowsystem.app.v3.fileprovider",cameraFile);
            Intent i=new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE); i.putExtra(android.provider.MediaStore.EXTRA_OUTPUT,cameraUri); i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivityForResult(i,10);
        }catch(Exception e){Toast.makeText(this,"Não foi possível abrir a câmera",Toast.LENGTH_SHORT).show();}
    }
    void gallery(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,11);}
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(result!=RESULT_OK)return;
        if(req==10 && cameraFile!=null && cameraFile.exists()){addPhoto(cameraFile.getAbsolutePath());}
        else if(req==11 && data!=null && data.getData()!=null){try{getContentResolver().takePersistableUriPermission(data.getData(),Intent.FLAG_GRANT_READ_URI_PERMISSION); }catch(Exception ignored){} addPhoto(data.getData().toString());}
    }
    void addPhoto(String path){int total=prefs.getInt("total",0)+10; prefs.edit().putInt("total",total).putString("last_photo",path).putLong("last_photo_time",System.currentTimeMillis()).apply(); view.invalidate(); Toast.makeText(this,"EVOLUÇÃO REGISTRADA  +10 XP",Toast.LENGTH_SHORT).show();}
    void input(String title,String hint,String key,int xpGain){
        final EditText e=new EditText(this);e.setHint(hint);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);e.setMinLines(4);
        new AlertDialog.Builder(this).setTitle(title).setView(e).setPositiveButton("Salvar",(d,w)->{String s=e.getText().toString().trim();if(!s.isEmpty()){prefs.edit().putString(key,s).apply();gain(xpGain);}}).setNegativeButton("Cancelar",null).show();
    }
    void gain(int add){int xp=prefs.getInt("xp",0)+add, level=prefs.getInt("level",1), total=prefs.getInt("total",0)+add; while(xp>=level*100){xp-=level*100;level++;Toast.makeText(this,"LEVEL UP!  NOVO NÍVEL "+level,Toast.LENGTH_LONG).show();}prefs.edit().putInt("xp",xp).putInt("level",level).putInt("total",total).apply();view.invalidate();}

    void profile(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(24,8,24,0);
        EditText name=new EditText(this); name.setHint("Seu nome"); name.setText(prefs.getString("name","VINÍCIUS"));
        EditText nick=new EditText(this); nick.setHint("Seu nickname (ex.: SHADOW)"); nick.setText(prefs.getString("nick","SHADOW"));
        box.addView(name); box.addView(nick);
        new AlertDialog.Builder(this).setTitle("EDITAR PERFIL").setView(box)
            .setPositiveButton("SALVAR",(d,w)->{
                String n=name.getText().toString().trim(); String k=nick.getText().toString().trim();
                if(n.isEmpty()) n="VINÍCIUS"; if(k.isEmpty()) k="SHADOW";
                prefs.edit().putString("name",n).putString("nick",k).apply(); view.invalidate();
                Toast.makeText(this,"PERFIL ATUALIZADO",Toast.LENGTH_SHORT).show();
            }).setNegativeButton("CANCELAR",null).show();
    }
    void weight(){final EditText e=new EditText(this);e.setHint("Peso em kg");e.setInputType(2|8192);new AlertDialog.Builder(this).setTitle("Registrar peso").setView(e).setPositiveButton("Salvar",(d,w)->{try{prefs.edit().putInt("weight",Integer.parseInt(e.getText().toString())).apply();gain(5);}catch(Exception ignored){}}).setNegativeButton("Cancelar",null).show();}
    void bonus(){String[][] m={{"CORRA +2 KM","Complete uma corrida extra de pelo menos 2 km",100},{"LEIA 20 PÁGINAS","Leia um livro por 20 páginas",70},{"ESTUDE 45 MIN","Foco total em estudo por 45 minutos",90},{"MOBILIDADE 15 MIN","Faça 15 minutos de alongamento/mobilidade",60},{"SEM REFRI HOJE","Passe o dia sem refrigerante",80},{"10K PASSOS","Bata 10 mil passos hoje",100},{"ORGANIZE O QUARTO","Deixe seu ambiente pronto para vencer",40}};Random r=new Random();String[] x=m[r.nextInt(m.length)];new AlertDialog.Builder(this).setTitle("⚡ MISSÃO BÔNUS").setMessage(x[0]+"\n\n"+x[1]+"\n\nRECOMPENSA: +"+x[2]+" XP").setPositiveButton("CONCLUIR",(d,w)->gain(x[2])).setNegativeButton("DEPOIS",null).show();}

    class SystemView extends View{
        Paint p=new Paint(3);float den;int bg=Color.rgb(5,5,9),panel=Color.rgb(14,14,22),purple=Color.rgb(139,92,246),cyan=Color.rgb(34,211,238),white=Color.WHITE,muted=Color.rgb(155,155,175),green=Color.rgb(74,222,128); 
        SystemView(){super(MainActivity.this);den=getResources().getDisplayMetrics().density;}
        void t(Canvas c,String s,float x,float y,float z,int col,Paint.Align a,boolean b){p.setStyle(Paint.Style.FILL);p.setColor(col);p.setTextSize(z*den);p.setTextAlign(a);p.setTypeface(Typeface.create("sans",b?Typeface.BOLD:Typeface.NORMAL));c.drawText(s,x,y,p);}
        void box(Canvas c,float l,float top,float rr,float bb){p.setColor(panel);p.setStyle(Paint.Style.FILL);c.drawRoundRect(new RectF(l,top,rr,bb),18*den,18*den,p);}
        String rank(int l){if(l>=16)return"S";if(l>=13)return"A";if(l>=10)return"B";if(l>=7)return"C";if(l>=4)return"D";return"E";}
        @Override protected void onDraw(Canvas c){c.drawColor(bg);float d=den,w=getWidth();int xp=prefs.getInt("xp",0),lv=prefs.getInt("level",1),total=prefs.getInt("total",0),weight=prefs.getInt("weight",85);
            t(c,"SHADOW SYSTEM",24*d,40*d,22,white,Paint.Align.LEFT,true);t(c,"SEU PROGRESSO. SEU SISTEMA. SUA EVOLUÇÃO.",24*d,62*d,9,muted,Paint.Align.LEFT,false);
            box(c,18*d,82*d,w-18*d,205*d);t(c,prefs.getString("nick","SHADOW"),34*d,112*d,18,white,Paint.Align.LEFT,true);t(c,prefs.getString("name","VINÍCIUS"),34*d,138*d,10,muted,Paint.Align.LEFT,false);t(c,rank(lv),34*d,177*d,42,purple,Paint.Align.LEFT,true);t(c,"LV.",w-34*d,116*d,12,muted,Paint.Align.RIGHT,true);t(c,""+lv,w-34*d,154*d,34,white,Paint.Align.RIGHT,true);t(c,xp+" / "+(lv*100)+" XP",w-34*d,179*d,10,muted,Paint.Align.RIGHT,false);
            p.setColor(Color.rgb(35,35,48));c.drawRoundRect(new RectF(150*d,151*d,w-52*d,165*d),7*d,7*d,p);p.setColor(purple);float f=Math.min(1f,xp/(float)(lv*100));c.drawRoundRect(new RectF(150*d,151*d,150*d+(w-202*d)*f,165*d),7*d,7*d,p);
            t(c,"STREAK",34*d,231*d,11,muted,Paint.Align.LEFT,true);t(c,prefs.getInt("streak",0)+" DIAS",34*d,257*d,22,white,Paint.Align.LEFT,true);t(c,"XP TOTAL",w/2,231*d,11,muted,Paint.Align.CENTER,true);t(c,""+total,w/2,257*d,22,cyan,Paint.Align.CENTER,true);t(c,"PERFIL • TOQUE PARA EDITAR",w-34*d,203*d,8,muted,Paint.Align.RIGHT,false);t(c,"PESO",w-34*d,231*d,11,muted,Paint.Align.RIGHT,true);t(c,weight+" kg",w-34*d,257*d,22,white,Paint.Align.RIGHT,true);
            t(c,"MISSÕES DE HOJE",24*d,295*d,16,white,Paint.Align.LEFT,true);mission(c,"CARDIO",318,35);mission(c,"MUSCULAÇÃO",360,40);mission(c,"ALIMENTAÇÃO",402,30);mission(c,"HIDRATAÇÃO",444,15);
            t(c,"EVOLUÇÃO",24*d,495*d,16,white,Paint.Align.LEFT,true);button(c,"📸  FOTO DO SHAPE",24,512,210,562);button(c,"🍽  REGISTRAR DIETA",218,512,(int)(w/d)-24,562);button(c,"🧠  PENSAMENTO / HUMOR",24,570,250,620);button(c,"⚡  MISSÃO BÔNUS",258,570,(int)(w/d)-24,620);
            t(c,"PROGRESSO",24*d,654*d,16,white,Paint.Align.LEFT,true);button(c,"GALERIA",24,672,150,720);button(c,"PESO",158,672,284,720);String last=prefs.getString("last_photo","");t(c,last.isEmpty()?"Nenhuma evolução registrada ainda":"Última evolução registrada",w/2,750*d,10,muted,Paint.Align.CENTER,false);
        }
        void mission(Canvas c,String n,int y,int xv){float d=den;box(c,18*d,(y-13)*d,getWidth()-18*d,(y+25)*d);t(c,n,32*d,(y+10)*d,11,white,Paint.Align.LEFT,true);t(c,"+"+xv+" XP",getWidth()-34*d,(y+10)*d,11,cyan,Paint.Align.RIGHT,true);}
        void button(Canvas c,String s,int x,int y,int rr,int bb){float d=den;p.setColor(Color.rgb(24,22,38));c.drawRoundRect(new RectF(x*d,y*d,rr*d,bb*d),14*d,14*d,p);t(c,s,(x+rr)/2f*d,(y+31)*d,11,white,Paint.Align.CENTER,true);}
        @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX()/den,y=e.getY()/den;float w=getWidth()/den;
            if(y>=82&&y<=205){profile();return true;}
            if(y>=512&&y<=562){if(x<214)camera();else input("Registrar dieta","Ex.: proteína, água, refeições, como foi sua alimentação...","diet",30);return true;}
            if(y>=570&&y<=620){if(x<254)input("Como você está?","Escreva o que está pensando e sentindo...","mind",15);else bonus();return true;}
            if(y>=672&&y<=720){if(x<154)gallery();else weight();return true;}return true;}
    }
}
