package com.shadowsystem.app;

import android.app.*;
import android.content.*;
import android.os.Build;

import java.util.*;

public class MissionReceiver extends BroadcastReceiver {
    static final String CHANNEL = "shadow_missions";
    static final String[] TITLES = {"CORRA +2 KM","LEIA 20 PÁGINAS","ESTUDE 45 MIN","MOBILIDADE 15 MIN","SEM REFRI HOJE","10K PASSOS","ORGANIZE O QUARTO","BÔNUS: 50 FLEXÕES","BÔNUS: 30 MIN SEM CELULAR"};
    static final String[] DESC = {"Complete uma corrida extra de pelo menos 2 km.","Leia 20 páginas de um livro.","Foco total em estudo por 45 minutos.","Faça 15 minutos de alongamento/mobilidade.","Passe o dia sem refrigerante.","Bata 10 mil passos hoje.","Deixe seu ambiente pronto para vencer.","Faça 50 flexões ao longo do dia.","Passe 30 minutos longe das redes sociais."};
    static final int[] XP = {100,70,90,60,80,100,40,90,75};

    @Override public void onReceive(Context context, Intent intent) {
        int index = intent.getIntExtra("mission_index", new Random().nextInt(TITLES.length));
        index = Math.max(0, Math.min(index, TITLES.length-1));
        createChannel(context);
        Intent open = new Intent(context, MainActivity.class).putExtra("bonus_index", index).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(context, 7000 + index, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(context, CHANNEL) : new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("⚡ MISSÃO BÔNUS DETECTADA").setContentText(TITLES[index] + " • +" + XP[index] + " XP").setStyle(new Notification.BigTextStyle().bigText(DESC[index] + "\nRecompensa: +" + XP[index] + " XP")).setAutoCancel(true).setContentIntent(pi).setPriority(Notification.PRIORITY_HIGH);
        if (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission("android.permission.POST_NOTIFICATIONS") == 0) ((NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE)).notify(7000 + index, b.build());
        MainActivity.scheduleNextMission(context, index);
    }
    static void createChannel(Context c){ if(Build.VERSION.SDK_INT>=26){ NotificationChannel ch=new NotificationChannel(CHANNEL,"Missões bônus",NotificationManager.IMPORTANCE_HIGH); ch.setDescription("Missões aleatórias do SHADOW SYSTEM"); ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch); } }
}
