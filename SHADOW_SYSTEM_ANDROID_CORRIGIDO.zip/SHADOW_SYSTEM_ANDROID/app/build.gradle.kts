plugins { id("com.android.application") }

android {
    namespace = "com.shadowsystem.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.shadowsystem.app"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
}
