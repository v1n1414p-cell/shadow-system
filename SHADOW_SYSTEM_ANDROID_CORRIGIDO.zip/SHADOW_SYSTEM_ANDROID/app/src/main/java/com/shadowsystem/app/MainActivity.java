package com.shadowsystem.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    SystemView view;
    SharedPreferences prefs;
    @Override public void onCreate(Bundle b){ super.onCreate(b); prefs=getSharedPreferences("shadow",0); view=new SystemView(); setContentView(view); }

    class SystemView extends View {
        Paint p=new Paint(3); float den; int xp, level, streak, weight; long wedding;
        RectF r=new RectF();
        int bg=Color.rgb(5,5,9), panel=Color.rgb(14,14,22), purple=Color.rgb(139,92,246), cyan=Color.rgb(34,211,238), white=Color.WHITE, muted=Color.rgb(155,155,175), green=Color.rgb(74,222,128);
        SystemView(){ super(MainActivity.this); den=getResources().getDisplayMetrics().density; load(); setFocusable(true); }
        void load(){ xp=prefs.getInt("xp",0); level=prefs.getInt("level",1); streak=prefs.getInt("streak",0); weight=prefs.getInt("weight",85); wedding=prefs.getLong("wedding",0); }
        void save(){ prefs.edit().putInt("xp",xp).putInt("level",level).putInt("streak",streak).putInt("weight",weight).apply(); }
        String rank(){ if(level>=16)return "S"; if(level>=13)return "A"; if(level>=10)return "B"; if(level>=7)return "C"; if(level>=4)return "D"; return "E"; }
        int next(){ return level*100; }
        void text(Canvas c,String s,float x,float y,float size,int color,Paint.Align a){p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.create("sans",Typeface.NORMAL));p.setTextSize(size*den);p.setColor(color);p.setTextAlign(a);c.drawText(s,x,y,p);}
        void bold(Canvas c,String s,float x,float y,float size,int color,Paint.Align a){p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.create("sans",Typeface.BOLD));p.setTextSize(size*den);p.setColor(color);p.setTextAlign(a);c.drawText(s,x,y,p);}
        void box(Canvas c,float l,float t,float rr,float bb){p.setStyle(Paint.Style.FILL);p.setColor(panel);c.drawRoundRect(new RectF(l,t,rr,bb),18*den,18*den,p);}
        @Override protected void onDraw(Canvas c){ super.onDraw(c); c.drawColor(bg); float w=getWidth(), d=den; 
            bold(c,"SHADOW SYSTEM",24*d,40*d,22,white,Paint.Align.LEFT); text(c,"SEU PROGRESSO. SEU SISTEMA. SUA EVOLUÇÃO.",24*d,62*d,9,muted,Paint.Align.LEFT);
            box(c,18*d,82*d,w-18*d,205*d); bold(c,"VINÍCIUS",34*d,112*d,18,white,Paint.Align.LEFT); text(c,"RANK",34*d,138*d,10,muted,Paint.Align.LEFT); bold(c,rank(),34*d,177*d,42,purple,Paint.Align.LEFT);
            bold(c,"LV.",w-34*d,116*d,12,muted,Paint.Align.RIGHT); bold(c,String.valueOf(level),w-34*d,154*d,34,white,Paint.Align.RIGHT); text(c,xp+" / "+next()+" XP",w-34*d,179*d,10,muted,Paint.Align.RIGHT);
            p.setColor(Color.rgb(35,35,48));c.drawRoundRect(new RectF(150*d,151*d,w-52*d,165*d),7*d,7*d,p);p.setColor(purple);float frac=Math.min(1f,xp/(float)next());c.drawRoundRect(new RectF(150*d,151*d,150*d+(w-202*d)*frac,165*d),7*d,7*d,p);
            bold(c,"STREAK",34*d,231*d,11,muted,Paint.Align.LEFT);bold(c,streak+" DIAS",34*d,257*d,22,white,Paint.Align.LEFT);bold(c,"XP TOTAL",w/2,231*d,11,muted,Paint.Align.CENTER);bold(c,String.valueOf(prefs.getInt("total",xp)),w/2,257*d,22,cyan,Paint.Align.CENTER);bold(c,"PESO",w-34*d,231*d,11,muted,Paint.Align.RIGHT);bold(c,weight+" kg",w-34*d,257*d,22,white,Paint.Align.RIGHT);
            bold(c,"ATRIBUTOS",24*d,295*d,16,white,Paint.Align.LEFT); attr(c,"FORÇA",prefs.getInt("str",1),24,318); attr(c,"RESISTÊNCIA",prefs.getInt("res",1),24,356); attr(c,"VITALIDADE",prefs.getInt("vit",1),24,394); attr(c,"DISCIPLINA",prefs.getInt("dis",1),24,432);
            bold(c,"MISSÕES DE HOJE",24*d,481*d,16,white,Paint.Align.LEFT); mission(c,"CARDIO",507,35); mission(c,"MUSCULAÇÃO",551,40); mission(c,"ALIMENTAÇÃO",595,30); mission(c,"HIDRATAÇÃO",639,15);
            bold(c,"AÇÕES",24*d,704*d,16,white,Paint.Align.LEFT); button(c,"+35 XP",24,722,130,770); button(c,"+40 XP",145,722,251,770); button(c,"+30 XP",266,722,372,770); button(c,"PESO",387,722,(int)(w/d)-24,770);
            text(c,"Toque nas ações para registrar progresso",w/2,804*d,10,muted,Paint.Align.CENTER);
        }
        void attr(Canvas c,String name,int val,float x,float y){ float d=den; text(c,name,x*d,y*d,10,muted,Paint.Align.LEFT); bold(c,"LV "+val,x*d,y*d+19*d,13,white,Paint.Align.LEFT); p.setColor(Color.rgb(40,40,52));c.drawRoundRect(new RectF(125*d,(y-10)*d,getWidth()-28*d,(y+1)*d),6*d,6*d,p);p.setColor(cyan);c.drawRoundRect(new RectF(125*d,(y-10)*d,125*d+Math.min(1f,val/10f)*(getWidth()/d-153)*d,(y+1)*d),6*d,6*d,p); }
        void mission(Canvas c,String n,int y,int xpVal){ float d=den; box(c,18*d,(y-13)*d,getWidth()-18*d,(y+25)*d);bold(c,n,32*d,(y+10)*d,11,white,Paint.Align.LEFT);text(c,"+"+xpVal+" XP",getWidth()-34*d,(y+10)*d,11,cyan,Paint.Align.RIGHT); }
        void button(Canvas c,String s,int x,int y,int rr,int bb){float d=den;p.setColor(Color.rgb(24,22,38));c.drawRoundRect(new RectF(x*d,y*d,rr*d,bb*d),14*d,14*d,p);bold(c,s,(x+rr)/2f*d,(y+30)*d,12,white,Paint.Align.CENTER);}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){ if(e.getAction()!=MotionEvent.ACTION_UP)return true; float x=e.getX()/den,y=e.getY()/den;
            if(y>=722&&y<=785){ int add=0; if(x<140)add=35; else if(x<260)add=40; else if(x<380)add=30; else { final EditText input=new EditText(MainActivity.this); input.setHint("Peso em kg"); input.setInputType(2); new AlertDialog.Builder(MainActivity.this).setTitle("Registrar peso").setView(input).setPositiveButton("Salvar",(d,w)->{try{weight=Integer.parseInt(input.getText().toString());save();invalidate();}catch(Exception ignored){}}).setNegativeButton("Cancelar",null).show(); return true; }
                xp+=add; int total=prefs.getInt("total",0)+add; while(xp>=next()){xp-=next();level++; Toast.makeText(MainActivity.this,"LEVEL UP! NOVO NÍVEL "+level,Toast.LENGTH_SHORT).show();}
                prefs.edit().putInt("total",total).apply(); save(); invalidate(); return true; }
            return true;
        }
    }
}
