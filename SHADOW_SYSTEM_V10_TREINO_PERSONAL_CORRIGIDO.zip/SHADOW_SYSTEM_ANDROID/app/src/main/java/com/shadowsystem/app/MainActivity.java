package com.shadowsystem.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import androidx.core.content.FileProvider;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    static volatile MainActivity activeInstance;
    SharedPreferences prefs; SystemView view; Uri cameraUri; File cameraFile;
    static final int REQ_CAMERA=91, REQ_NOTIFY=92;
    static final String[] BONUS_TITLES=MissionReceiver.TITLES; static final String[] BONUS_DESC=MissionReceiver.DESC; static final int[] BONUS_XP=MissionReceiver.XP;
    @Override public void onCreate(Bundle b){ super.onCreate(b); activeInstance=this; prefs=getSharedPreferences("shadow",0); showSplash(); if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFY); scheduleMissions(this); }
    @Override protected void onResume(){ super.onResume(); activeInstance=this; checkPendingBonus(); }
    @Override protected void onPause(){ if(activeInstance==this) activeInstance=null; super.onPause(); }
    void checkPendingBonus(){
        long id=prefs.getLong("pending_bonus_id",0L);
        if(id!=0L){
            prefs.edit().remove("pending_bonus_id").apply();
            new Handler(Looper.getMainLooper()).postDelayed(()->bonusDialog(id),250);
        }
    }
    static void showBonusIfOpen(long id){
        MainActivity a=activeInstance;
        if(a!=null){
            new Handler(Looper.getMainLooper()).post(()->a.bonusDialog(id));
        }
    }
    void showSplash(){ final FrameLayout f=new FrameLayout(this); f.setBackgroundColor(Color.rgb(5,5,9)); ImageView im=new ImageView(this); im.setImageResource(com.shadowsystem.app.R.drawable.shadow_logo); im.setScaleType(ImageView.ScaleType.CENTER_INSIDE); f.addView(im,new FrameLayout.LayoutParams(-1,-1)); TextView q=new TextView(this); q.setText("DISCIPLINA É EVOLUÇÃO"); q.setTextColor(Color.WHITE); q.setTextSize(14); q.setGravity(Gravity.CENTER); FrameLayout.LayoutParams qp=new FrameLayout.LayoutParams(-1,60); qp.gravity=Gravity.BOTTOM; f.addView(q,qp); setContentView(f); new Handler().postDelayed(()->{view=new SystemView();setContentView(view); showBonusFromIntent(getIntent());},1800); }
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);showBonusFromIntent(i);}
    void showBonusFromIntent(Intent i){
        if(i!=null && i.hasExtra("bonus_id")){
            long id=i.getLongExtra("bonus_id",0L);
            new Handler().postDelayed(()->bonusDialog(id),400);
            i.removeExtra("bonus_id");
        }
    }
    static void scheduleMissions(Context c){
        SharedPreferences p=c.getSharedPreferences("shadow",0);
        String today=new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date());
        if(today.equals(p.getString("mission_schedule",""))) return;
        p.edit().putString("mission_schedule",today).apply();
        AlarmManager am=(AlarmManager)c.getSystemService(ALARM_SERVICE);
        Random r=new Random();
        long now=System.currentTimeMillis();
        Calendar end=Calendar.getInstance();
        end.set(Calendar.HOUR_OF_DAY,23); end.set(Calendar.MINUTE,50); end.set(Calendar.SECOND,0); end.set(Calendar.MILLISECOND,0);
        long available=Math.max(60*60*1000L,end.getTimeInMillis()-now);
        ArrayList<Long> offsets=new ArrayList<>();
        for(int k=0;k<3;k++){
            long off=10*60*1000L+(long)(r.nextDouble()*Math.max(1,available-20*60*1000L));
            offsets.add(off);
        }
        Collections.sort(offsets);
        for(int k=0;k<3;k++){
            Calendar at=Calendar.getInstance();
            at.setTimeInMillis(now+offsets.get(k));
            int idx=r.nextInt(BONUS_TITLES.length);
            long id=System.currentTimeMillis()+r.nextInt(1000000)+k;
            Intent in=new Intent(c,MissionReceiver.class).putExtra("mission_index",idx).putExtra("bonus_id",id);
            PendingIntent pi=PendingIntent.getBroadcast(c,5000+k,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at.getTimeInMillis(),pi);
        }
    }
    void bonusDialog(long id){
        String prefix="bonus_"+id+"_";
        int n=prefs.getInt(prefix+"index",-1);
        if(n<0 || n>=BONUS_TITLES.length) return;
        int xp=BONUS_XP[n];
        String rarity=xp>=100?"🔥 LENDÁRIA":xp>=90?"🟣 ÉPICA":xp>=70?"🔵 RARA":"🟢 COMUM";
        boolean done=prefs.getBoolean(prefix+"done",false);
        AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle("⚡ MISSÃO BÔNUS • "+rarity)
            .setMessage(BONUS_TITLES[n]+"\n\n"+BONUS_DESC[n]+"\n\nRECOMPENSA FIXA: +"+xp+" XP");
        if(done){ b.setPositiveButton("JÁ CONCLUÍDA",null); }
        else { b.setPositiveButton("✓ MARCAR CONCLUÍDA",(d,w)->{prefs.edit().putBoolean(prefix+"done",true).apply();gain(xp);}); b.setNegativeButton("FAZER DEPOIS",null); }
        b.show();
    }
    void camera(boolean diet){ if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_CAMERA);return;} try{ File dir=new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES),diet?"dieta":"evolucao");if(!dir.exists())dir.mkdirs();String name=(diet?"refeicao_":"shape_")+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".jpg";cameraFile=new File(dir,name);cameraUri=FileProvider.getUriForFile(this,"com.shadowsystem.app.v5.fileprovider",cameraFile);Intent i=new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);i.putExtra(android.provider.MediaStore.EXTRA_OUTPUT,cameraUri);i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);i.putExtra("diet",diet);startActivityForResult(i,diet?12:10);}catch(Exception e){Toast.makeText(this,"Não foi possível abrir a câmera",Toast.LENGTH_SHORT).show();} }
    void gallery(boolean diet){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,diet?13:11);}
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(result!=RESULT_OK)return;boolean diet=req==12||req==13;if((req==10||req==12)&&cameraFile!=null&&cameraFile.exists()){addPhoto(cameraFile.getAbsolutePath(),diet);}else if((req==11||req==13)&&data!=null&&data.getData()!=null){addPhoto(data.getData().toString(),diet);} }
    void addPhoto(String path,boolean diet){prefs.edit().putString((diet?"last_diet_photo":"last_photo"),path).putLong((diet?"last_diet_time":"last_photo_time"),System.currentTimeMillis()).apply();gain(diet?30:10);Toast.makeText(this,diet?"REFEIÇÃO REGISTRADA +30 XP":"EVOLUÇÃO REGISTRADA +10 XP",Toast.LENGTH_SHORT).show();}
    void input(String title,String hint,String key,int xp){final EditText e=new EditText(this);e.setHint(hint);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);e.setMinLines(4);new AlertDialog.Builder(this).setTitle(title).setView(e).setPositiveButton("SALVAR",(d,w)->{String s=e.getText().toString().trim();if(!s.isEmpty()){prefs.edit().putString(key,s).apply();gain(xp);}}).setNegativeButton("CANCELAR",null).show();}
    void gain(int add){adjustTotalXp(add);}
    int xpToReachLevel(int level){int sum=0;for(int i=1;i<level;i++)sum+=i*100;return sum;}
    void adjustTotalXp(int delta){int oldTotal=prefs.getInt("total",0);int newTotal=Math.max(0,oldTotal+delta);int level=1;while(xpToReachLevel(level+1)<=newTotal)level++;int current=newTotal-xpToReachLevel(level);int oldLevel=prefs.getInt("level",1);prefs.edit().putInt("total",newTotal).putInt("level",level).putInt("xp",current).apply();if(level>oldLevel)Toast.makeText(this,"LEVEL UP!  NOVO NÍVEL "+level,Toast.LENGTH_LONG).show();if(view!=null)view.invalidate();}
    void profile(){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(24,8,24,0);EditText name=new EditText(this);name.setHint("Seu nome");name.setText(prefs.getString("name","VINÍCIUS"));EditText nick=new EditText(this);nick.setHint("Nickname");nick.setText(prefs.getString("nick","SHADOW"));box.addView(name);box.addView(nick);new AlertDialog.Builder(this).setTitle("EDITAR PERFIL").setView(box).setPositiveButton("SALVAR",(d,w)->{String n=name.getText().toString().trim(),k=nick.getText().toString().trim();if(n.isEmpty())n="VINÍCIUS";if(k.isEmpty())k="SHADOW";prefs.edit().putString("name",n).putString("nick",k).apply();view.invalidate();}).setNegativeButton("CANCELAR",null).show();}
    String waterDay(){return new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date());}
    int waterGoal(){return prefs.getInt("water_goal_ml",2500);}
    int waterMl(){String d=prefs.getString("water_day","");if(!d.equals(waterDay())){prefs.edit().putString("water_day",waterDay()).putInt("water_ml",0).putBoolean("water_done",false).apply();return 0;}return prefs.getInt("water_ml",0);}
    void waterTracker(){
        int current=waterMl(), goal=waterGoal();
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(24,8,24,0);
        TextView progress=new TextView(this);progress.setText("Hoje: "+current+" ml / "+goal+" ml");progress.setTextSize(18);progress.setPadding(0,8,0,12);
        EditText goalInput=new EditText(this);goalInput.setHint("Meta diária em ml (ex.: 2500)");goalInput.setInputType(2);goalInput.setText(String.valueOf(goal));
        EditText amountInput=new EditText(this);amountInput.setHint("Quantidade que você tomou (ml)");amountInput.setInputType(2);
        LinearLayout quick=new LinearLayout(this);quick.setOrientation(LinearLayout.HORIZONTAL);
        Button b120=new Button(this);b120.setText("+120");Button b250=new Button(this);b250.setText("+250");Button b500=new Button(this);b500.setText("+500");
        quick.addView(b120,new LinearLayout.LayoutParams(0,56,1));quick.addView(b250,new LinearLayout.LayoutParams(0,56,1));quick.addView(b500,new LinearLayout.LayoutParams(0,56,1));
        b120.setOnClickListener(v->addWater(120,goalInput));
        b250.setOnClickListener(v->addWater(250,goalInput));
        b500.setOnClickListener(v->addWater(500,goalInput));
        box.addView(progress);box.addView(goalInput);box.addView(amountInput);box.addView(quick);
        new AlertDialog.Builder(this).setTitle("💧 META DE ÁGUA").setView(box)
            .setPositiveButton("ADICIONAR ML",(d,w)->{try{int amount=Integer.parseInt(amountInput.getText().toString());if(amount>0)addWater(amount,goalInput);}catch(Exception ignored){}})
            .setNeutralButton("SALVAR META",(d,w)->saveWaterGoal(goalInput))
            .setNegativeButton("FECHAR",null).show();
    }
    void saveWaterGoal(EditText e){try{int g=Math.max(500,Integer.parseInt(e.getText().toString()));prefs.edit().putInt("water_goal_ml",g).apply();if(view!=null)view.invalidate();Toast.makeText(this,"META DE ÁGUA: "+g+" ml",Toast.LENGTH_SHORT).show();}catch(Exception ignored){}}
    void addWater(int amount,EditText goalInput){try{int g=Math.max(500,Integer.parseInt(goalInput.getText().toString()));prefs.edit().putInt("water_goal_ml",g).apply();}catch(Exception ignored){}int total=waterMl()+amount;boolean already=prefs.getBoolean("water_done",false);prefs.edit().putInt("water_ml",total).putString("water_day",waterDay()).apply();if(total>=waterGoal()&&!already){prefs.edit().putBoolean("water_done",true).apply();gain(15);Toast.makeText(this,"💧 META DE ÁGUA CONCLUÍDA! +15 XP",Toast.LENGTH_LONG).show();}else{Toast.makeText(this,"+"+amount+" ml • "+total+" / "+waterGoal()+" ml",Toast.LENGTH_SHORT).show();}if(view!=null)view.invalidate();}
    void weight(){final EditText e=new EditText(this);e.setHint("Peso em kg");e.setInputType(2|8192);new AlertDialog.Builder(this).setTitle("Registrar peso").setView(e).setPositiveButton("SALVAR",(d,w)->{try{prefs.edit().putInt("weight",Integer.parseInt(e.getText().toString())).apply();gain(5);}catch(Exception ignored){}}).setNegativeButton("Cancelar",null).show();}
    void tips(){String[] t={"TREINO • Comece com 5–10 min de aquecimento e priorize técnica.","TREINO • Aumente carga ou repetições aos poucos, sem sacrificar a execução.","DIETA • Monte refeições com proteína, vegetais e uma fonte de carboidrato conforme seu objetivo.","DIETA • Hidrate-se ao longo do dia e mantenha refeições simples e consistentes.","DISCIPLINA • O objetivo é repetir bons hábitos, não buscar perfeição."};new AlertDialog.Builder(this).setTitle("📚 DICAS DO SISTEMA").setMessage(t[new Random().nextInt(t.length)]).setPositiveButton("OK",null).show();}

    class SystemView extends View{
        Paint p=new Paint(3);float den;int tab=0;float downX;int bg=Color.rgb(5,5,9),panel=Color.rgb(14,14,22),purple=Color.rgb(139,92,246),cyan=Color.rgb(34,211,238),white=Color.WHITE,muted=Color.rgb(155,155,175),green=Color.rgb(74,222,128),red=Color.rgb(248,80,80);
        SystemView(){super(MainActivity.this);den=getResources().getDisplayMetrics().density;}
        void t(Canvas c,String s,float x,float y,float z,int col,Paint.Align a,boolean b){p.setStyle(Paint.Style.FILL);p.setColor(col);p.setTextSize(z*den);p.setTextAlign(a);p.setTypeface(Typeface.create("sans",b?Typeface.BOLD:Typeface.NORMAL));c.drawText(s,x,y,p);}
        void box(Canvas c,float l,float top,float rr,float bb){p.setColor(panel);p.setStyle(Paint.Style.FILL);c.drawRoundRect(new RectF(l,top,rr,bb),18*den,18*den,p);}
        String rank(int l){if(l>=16)return"S";if(l>=13)return"A";if(l>=10)return"B";if(l>=7)return"C";if(l>=4)return"D";return"E";}
        @Override protected void onDraw(Canvas c){c.drawColor(bg);float d=den,w=getWidth();t(c,"SHADOW SYSTEM",22*d,36*d,21,white,Paint.Align.LEFT,true);t(c,"DESLIZE PARA NAVEGAR",w-22*d,36*d,8,muted,Paint.Align.RIGHT,false);String[] tabs={"INÍCIO","EVOLUÇÃO","TREINO","MISSÕES","DICAS"};for(int i=0;i<5;i++)t(c,tabs[i],(16+i*(w/d-32)/5)*d,66*d,8,i==tab?cyan:muted,Paint.Align.LEFT,true);p.setColor(iColor());c.drawRect(tab*(w/5),75*d,(tab+1)*(w/5),78*d,p);if(tab==0)home(c);else if(tab==1)evolution(c);else if(tab==2)workoutPage(c);else if(tab==3)missions(c);else tipsPage(c);}
        int iColor(){return cyan;}
        void home(Canvas c){float d=den,w=getWidth();int xp=prefs.getInt("xp",0),lv=prefs.getInt("level",1),total=prefs.getInt("total",0),weight=prefs.getInt("weight",85);box(c,18*d,92*d,w-18*d,216*d);try{Bitmap logo=BitmapFactory.decodeResource(getResources(),R.drawable.shadow_logo);RectF lr=new RectF(w-92*d,102*d,w-30*d,164*d);c.drawBitmap(logo,null,lr,p);}catch(Exception ignored){}t(c,prefs.getString("nick","SHADOW"),34*d,122*d,20,white,Paint.Align.LEFT,true);t(c,prefs.getString("name","VINÍCIUS"),34*d,147*d,10,muted,Paint.Align.LEFT,false);t(c,rank(lv),34*d,191*d,40,purple,Paint.Align.LEFT,true);t(c,"LV. "+lv,w-34*d,126*d,23,white,Paint.Align.RIGHT,true);t(c,xp+" / "+(lv*100)+" XP",w-34*d,153*d,10,muted,Paint.Align.RIGHT,false);p.setColor(Color.rgb(35,35,48));c.drawRoundRect(new RectF(150*d,173*d,w-52*d,187*d),7*d,7*d,p);p.setColor(purple);c.drawRoundRect(new RectF(150*d,173*d,150*d+(w-202*d)*Math.min(1f,xp/(float)(lv*100)),187*d),7*d,7*d,p);t(c,"STREAK",34*d,242*d,10,muted,Paint.Align.LEFT,true);t(c,prefs.getInt("streak",0)+" DIAS",34*d,266*d,20,white,Paint.Align.LEFT,true);t(c,"XP TOTAL",w/2,242*d,10,muted,Paint.Align.CENTER,true);t(c,""+total,w/2,266*d,20,cyan,Paint.Align.CENTER,true);t(c,"PESO",w-34*d,242*d,10,muted,Paint.Align.RIGHT,true);t(c,weight+" kg",w-34*d,266*d,20,white,Paint.Align.RIGHT,true);t(c,"MISSÕES DE HOJE",24*d,304*d,15,white,Paint.Align.LEFT,true);mission(c,"CARDIO",327,35,"cardio");mission(c,"MUSCULAÇÃO",369,40,"musculacao");mission(c,"ALIMENTAÇÃO",411,30,"alimentacao");waterMission(c,453);button(c,"👤  EDITAR PERFIL",24,495,190,543);button(c,"⚖  PESO",198,495,(int)(w/d)-24,543);}
        void mission(Canvas c,String n,int y,int xv,String key){float d=den;boolean done=isDoneToday(key);box(c,18*d,(y-13)*d,getWidth()-18*d,(y+25)*d);t(c,done?"✓":"□",32*d,(y+10)*d,17,done?green:muted,Paint.Align.LEFT,true);t(c,n,58*d,(y+10)*d,11,done?muted:white,Paint.Align.LEFT,true);t(c,"+"+xv+" XP",getWidth()-34*d,(y+10)*d,11,cyan,Paint.Align.RIGHT,true);}
        void waterMission(Canvas c,int y){float d=den;int ml=waterMl(),goal=waterGoal();boolean done=ml>=goal;box(c,18*d,(y-13)*d,getWidth()-18*d,(y+25)*d);t(c,done?"✓":"□",32*d,(y+10)*d,17,done?green:muted,Paint.Align.LEFT,true);t(c,"ÁGUA "+ml+" / "+goal+" ML",58*d,(y+10)*d,11,done?muted:white,Paint.Align.LEFT,true);t(c,"+15 XP",getWidth()-34*d,(y+10)*d,11,cyan,Paint.Align.RIGHT,true);}
        boolean isDoneToday(String key){return prefs.getString("done_"+key," ").equals(day());}String day(){return new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date());}
        void mark(String key,int xp){if(isDoneToday(key)){prefs.edit().remove("done_"+key).apply();adjustTotalXp(-xp);Toast.makeText(MainActivity.this,"MISSÃO DESMARCADA • -"+xp+" XP",Toast.LENGTH_SHORT).show();}else{prefs.edit().putString("done_"+key,day()).apply();gain(xp);Toast.makeText(MainActivity.this,"MISSÃO CONCLUÍDA • +"+xp+" XP",Toast.LENGTH_SHORT).show();}if(view!=null)view.invalidate();}
        void evolution(Canvas c){float d=den,w=getWidth();t(c,"EVOLUÇÃO",24*d,112*d,19,white,Paint.Align.LEFT,true);t(c,"Seu histórico fica salvo no aparelho.",24*d,135*d,10,muted,Paint.Align.LEFT,false);button(c,"📸  TIRAR FOTO DO SHAPE",24,155,270,208);button(c,"🖼  GALERIA",282,155,(int)(w/d)-24,208);button(c,"🍽  FOTO DA REFEIÇÃO",24,222,270,275);button(c,"🖼  GALERIA DA DIETA",282,222,(int)(w/d)-24,275);button(c,"🧠  PENSAMENTO / HUMOR",24,289,(int)(w/d)-24,342);t(c,"ÚLTIMO SHAPE",24*d,380*d,13,white,Paint.Align.LEFT,true);t(c,prefs.getString("last_photo","").isEmpty()?"Nenhuma foto registrada.":"Foto registrada • +10 XP",24*d,405*d,11,muted,Paint.Align.LEFT,false);t(c,"ÚLTIMA DIETA",24*d,445*d,13,white,Paint.Align.LEFT,true);t(c,prefs.getString("last_diet_photo","").isEmpty()?"Nenhuma refeição fotografada.":"Refeição registrada • +30 XP",24*d,470*d,11,muted,Paint.Align.LEFT,false);}
        void missions(Canvas c){float d=den,w=getWidth();t(c,"MISSÕES",24*d,112*d,19,white,Paint.Align.LEFT,true);t(c,"O SHADOW SYSTEM decide quando uma missão bônus chega.",24*d,135*d,10,muted,Paint.Align.LEFT,false);box(c,18*d,153*d,w-18*d,238*d);t(c,"⚡ MISSÃO BÔNUS",34*d,181*d,12,cyan,Paint.Align.LEFT,true);t(c,"3 missões bônus são sorteadas por dia.",34*d,207*d,11,white,Paint.Align.LEFT,false);t(c,"HORÁRIO + XP DEFINIDOS",w-34*d,207*d,10,purple,Paint.Align.RIGHT,true);t(c,"Você pode fazer depois. O valor da recompensa não muda.",24*d,270*d,10,muted,Paint.Align.LEFT,false);t(c,"Raridades: COMUM • RARA • ÉPICA • LENDÁRIA",24*d,300*d,10,muted,Paint.Align.LEFT,false);}
        void workoutPage(Canvas c){float d=den,w=getWidth();t(c,"FICHA DE TREINO",24*d,112*d,19,white,Paint.Align.LEFT,true);t(c,"Monte, registre e ajuste sua rotina.",24*d,135*d,10,muted,Paint.Align.LEFT,false);box(c,18*d,153*d,w-18*d,245*d);t(c,"🏋️ SUA FICHA",34*d,181*d,13,cyan,Paint.Align.LEFT,true);t(c,"Adicione exercícios, séries, repetições e carga.",34*d,207*d,10,white,Paint.Align.LEFT,false);t(c,"Toque para abrir a ficha completa.",34*d,230*d,10,muted,Paint.Align.LEFT,false);button(c,"🏋️  ABRIR FICHA + PERSONAL",24,265,(int)(w/d)-24,320);box(c,18*d,340*d,w-18*d,430*d);t(c,"🤖 PERSONAL",34*d,369*d,13,purple,Paint.Align.LEFT,true);t(c,"Ajuda a organizar volume, progressão e divisão.",34*d,395*d,10,white,Paint.Align.LEFT,false);t(c,"Use como orientação educativa.",34*d,417*d,10,muted,Paint.Align.LEFT,false);}void tipsPage(Canvas c){float d=den,w=getWidth();t(c,"DICAS",24*d,112*d,19,white,Paint.Align.LEFT,true);t(c,"Treino, alimentação e disciplina.",24*d,135*d,10,muted,Paint.Align.LEFT,false);box(c,18*d,153*d,w-18*d,290*d);t(c,"🏋️ TREINO",34*d,181*d,13,cyan,Paint.Align.LEFT,true);t(c,"• Aquecimento e técnica primeiro",34*d,207*d,11,white,Paint.Align.LEFT,false);t(c,"• Evolua carga/repetições gradualmente",34*d,231*d,11,white,Paint.Align.LEFT,false);t(c,"• Respeite recuperação e sono",34*d,255*d,11,white,Paint.Align.LEFT,false);box(c,18*d,308*d,w-18*d,445*d);t(c,"🥗 DIETA",34*d,336*d,13,green,Paint.Align.LEFT,true);t(c,"• Priorize proteína e alimentos variados",34*d,362*d,11,white,Paint.Align.LEFT,false);t(c,"• Hidrate-se durante o dia",34*d,386*d,11,white,Paint.Align.LEFT,false);t(c,"• Consistência > perfeição",34*d,410*d,11,white,Paint.Align.LEFT,false);t(c,"💧 ÁGUA • Defina uma meta e acompanhe ml ao longo do dia.",34*d,434*d,10,cyan,Paint.Align.LEFT,false);button(c,"🎲  DICA ALEATÓRIA",24,470,(int)(w/d)-24,520);button(c,"🤖  SHADOW IA • TIRAR DÚVIDAS",24,535,(int)(w/d)-24,590);}
        void button(Canvas c,String s,int x,int y,int rr,int bb){float d=den;p.setColor(Color.rgb(24,22,38));c.drawRoundRect(new RectF(x*d,y*d,rr*d,bb*d),14*d,14*d,p);t(c,s,(x+rr)/2f*d,(y+31)*d,10,white,Paint.Align.CENTER,true);}
        @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getX();return true;}if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX()/den,y=e.getY()/den,w=getWidth()/den;float dx=e.getX()-downX;if(Math.abs(dx)>80){if(dx<0)tab=Math.min(4,tab+1);else tab=Math.max(0,tab-1);invalidate();return true;}if(y<85){int nt=(int)(x/(getWidth()/5f));tab=Math.max(0,Math.min(4,nt));invalidate();return true;}if(tab==0){if(y>=327&&y<365)mark("cardio",35);else if(y>=369&&y<407)mark("musculacao",40);else if(y>=411&&y<449)mark("alimentacao",30);else if(y>=453&&y<480)waterTracker();else if(y>=495&&y<543&&x<195)profile();else if(y>=495&&y<543)weight();}else if(tab==1){if(y>=155&&y<208&&x<275)camera(false);else if(y>=155&&y<208)gallery(false);else if(y>=222&&y<275&&x<275)camera(true);else if(y>=222&&y<275)gallery(true);else if(y>=289&&y<342)input("PENSAMENTO / HUMOR","Como você está? O que está pensando ou sentindo?","mind",15);}else if(tab==2){if(y>=265&&y<325)startActivity(new Intent(MainActivity.this,WorkoutActivity.class));}else if(tab==3){}else if(tab==4){if(y>=470&&y<520)tips();else if(y>=535&&y<590)startActivity(new Intent(MainActivity.this,ChatActivity.class));}return true;}
}

}