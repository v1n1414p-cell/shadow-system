package com.shadowsystem.app;

import android.app.*;
import android.content.*;
import android.os.Build;
import android.content.SharedPreferences;

public class MissionReceiver extends BroadcastReceiver {
    static final String CHANNEL = "shadow_missions";
    static final String[] TITLES = {"CORRA +2 KM","LEIA 20 PÁGINAS","ESTUDE 45 MIN","MOBILIDADE 15 MIN","SEM REFRI HOJE","10K PASSOS","ORGANIZE O QUARTO","BÔNUS: 50 FLEXÕES","BÔNUS: 30 MIN SEM CELULAR"};
    static final String[] DESC = {"Complete uma corrida extra de pelo menos 2 km.","Leia 20 páginas de um livro.","Foco total em estudo por 45 minutos.","Faça 15 minutos de alongamento/mobilidade.","Passe o dia sem refrigerante.","Bata 10 mil passos hoje.","Deixe seu ambiente pronto para vencer.","Faça 50 flexões ao longo do dia.","Passe 30 minutos longe das redes sociais."};
    static final int[] XP = {100,70,90,60,80,100,40,90,75};

    @Override public void onReceive(Context context, Intent intent) {
        int index = intent.getIntExtra("mission_index", 0);
        long id = intent.getLongExtra("bonus_id", System.currentTimeMillis());
        if(index < 0 || index >= TITLES.length) index = 0;
        SharedPreferences prefs=context.getSharedPreferences("shadow",0);
        prefs.edit()
            .putInt("bonus_"+id+"_index", index)
            .putBoolean("bonus_"+id+"_done", false)
            .putLong("pending_bonus_id", id)
            .apply();
        boolean appOpen=MainActivity.activeInstance!=null;
        if(appOpen){
            prefs.edit().remove("pending_bonus_id").apply();
            MainActivity.showBonusIfOpen(id);
        }
        createChannel(context);
        Intent open = new Intent(context, MainActivity.class)
            .putExtra("bonus_id", id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(context, (int)(7000 + (id % 100000)), open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(context, CHANNEL) : new Notification.Builder(context);
        int xp=XP[index];
        String rarity=xp>=100?"LENDÁRIA":xp>=90?"ÉPICA":xp>=70?"RARA":"COMUM";
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("⚡ MISSÃO BÔNUS • "+rarity)
            .setContentText(TITLES[index] + " • +" + xp + " XP")
            .setStyle(new Notification.BigTextStyle().bigText(DESC[index] + "\nRecompensa fixa: +" + xp + " XP"))
            .setAutoCancel(true).setContentIntent(pi).setPriority(Notification.PRIORITY_HIGH);
        if (!appOpen && (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission("android.permission.POST_NOTIFICATIONS") == 0))
            ((NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE)).notify((int)(7000 + (id % 100000)), b.build());
    }
    static void createChannel(Context c){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CHANNEL,"Missões bônus",NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Missões aleatórias do SHADOW SYSTEM");
            ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }
}
