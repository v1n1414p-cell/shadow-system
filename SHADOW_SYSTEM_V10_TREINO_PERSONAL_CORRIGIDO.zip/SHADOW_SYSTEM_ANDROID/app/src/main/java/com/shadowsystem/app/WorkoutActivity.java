package com.shadowsystem.app;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.util.*;

public class WorkoutActivity extends Activity {
    SharedPreferences prefs;
    LinearLayout list;
    int white=Color.WHITE, muted=Color.rgb(175,175,195), panel=Color.rgb(18,16,28), cyan=Color.rgb(34,211,238), purple=Color.rgb(139,92,246), green=Color.rgb(74,222,128);
    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("shadow",0); build();}
    TextView tv(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(18,14,18,14);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(white);return b;}
    void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(12,12,12,12);root.setBackgroundColor(Color.rgb(5,5,9));
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
        Button back=btn("‹");head.addView(back,new LinearLayout.LayoutParams(58,58));back.setOnClickListener(v->finish());
        TextView title=tv("🏋️ FICHA DE TREINO",20,white);title.setTypeface(null,1);head.addView(title,new LinearLayout.LayoutParams(0,58,1));root.addView(head);
        TextView intro=tv("Monte sua ficha, registre cargas/repetições e peça ao Personal para ajustar a estrutura.",11,muted);root.addView(intro);
        LinearLayout actions=new LinearLayout(this);Button add=btn("+ ADICIONAR EXERCÍCIO");Button personal=btn("🤖 PERSONAL");actions.addView(add,new LinearLayout.LayoutParams(0,58,1));actions.addView(personal,new LinearLayout.LayoutParams(0,58,1));root.addView(actions);
        add.setOnClickListener(v->addExercise());personal.setOnClickListener(v->personalDialog());
        ScrollView sv=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);sv.addView(list);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);refresh();
    }
    void refresh(){list.removeAllViews();String data=prefs.getString("workout_sheet","");if(data.isEmpty()){list.addView(tv("Sua ficha ainda está vazia.\nAdicione seu primeiro exercício.",14,muted));return;}for(String item:data.split("\\n",-1)){if(item.trim().isEmpty())continue;LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView t=tv(item,13,white);row.addView(t,new LinearLayout.LayoutParams(0,-2,1));Button del=btn("✕");row.addView(del,new LinearLayout.LayoutParams(58,52));del.setOnClickListener(v->{removeExercise(item);});list.addView(row);}}
    void addExercise(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(18,4,18,0);
        EditText name=field("Exercício (ex.: Supino reto)");EditText sets=field("Séries (ex.: 4)");sets.setInputType(InputType.TYPE_CLASS_NUMBER);EditText reps=field("Repetições (ex.: 8-12)");EditText kg=field("Carga em kg (ex.: 30)");kg.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);EditText rest=field("Descanso em segundos (ex.: 90)");rest.setInputType(InputType.TYPE_CLASS_NUMBER);box.addView(name);box.addView(sets);box.addView(reps);box.addView(kg);box.addView(rest);
        new AlertDialog.Builder(this).setTitle("ADICIONAR EXERCÍCIO").setView(box).setPositiveButton("ADICIONAR",(d,w)->{String n=name.getText().toString().trim();if(n.isEmpty())return;String line=n+" • "+sets.getText().toString().trim()+"x"+reps.getText().toString().trim()+" • "+kg.getText().toString().trim()+" kg • descanso "+rest.getText().toString().trim()+"s";String old=prefs.getString("workout_sheet","");prefs.edit().putString("workout_sheet",old.isEmpty()?line:old+"\n"+line).apply();refresh();}).setNegativeButton("CANCELAR",null).show();
    }
    EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextColor(white);e.setHintTextColor(muted);e.setSingleLine(true);return e;}
    void removeExercise(String item){String old=prefs.getString("workout_sheet","");ArrayList<String> a=new ArrayList<>(Arrays.asList(old.split("\\n",-1)));a.remove(item);StringBuilder sb=new StringBuilder();for(String s:a)if(!s.trim().isEmpty()){if(sb.length()>0)sb.append('\n');sb.append(s);}prefs.edit().putString("workout_sheet",sb.toString()).apply();refresh();}
    void personalDialog(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(18,0,18,0);
        EditText goal=field("Objetivo: hipertrofia / força / resistência");EditText days=field("Quantos dias por semana? (ex.: 4)");days.setInputType(InputType.TYPE_CLASS_NUMBER);box.addView(goal);box.addView(days);
        new AlertDialog.Builder(this).setTitle("🤖 PERSONAL DO SHADOW SYSTEM").setMessage("Responda os dois campos e eu ajusto uma orientação geral para sua ficha.").setView(box).setPositiveButton("AJUSTAR",(d,w)->{String g=goal.getText().toString().toLowerCase(Locale.ROOT);int n=4;try{n=Integer.parseInt(days.getText().toString());}catch(Exception ignored){}String advice;if(g.contains("resist")||g.contains("cardio")){advice="Priorize progressão de volume e intensidade de forma gradual, com sessões fáceis e intensas distribuídas na semana. Inclua recuperação.";}else if(g.contains("força")||g.contains("forca")){advice="Priorize técnica, exercícios compostos, cargas desafiadoras e descanso adequado. Registre cargas para controlar a progressão.";}else{advice="Para hipertrofia, organize volume semanal por músculo, use boa técnica, progrida carga/repetições e mantenha recuperação, proteína e sono adequados.";}advice += "\n\nCom "+n+" dias/semana, posso ajudar a dividir os grupos musculares e revisar sua ficha. Esta é uma orientação educativa, não substitui um profissional presencial.";new AlertDialog.Builder(this).setTitle("AJUSTE DO PERSONAL").setMessage(advice).setPositiveButton("OK",null).show();}).setNegativeButton("CANCELAR",null).show();
    }
}
