package com.shadowsystem.app;

import android.app.*;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.util.*;

public class ChatActivity extends Activity {
    LinearLayout messages; EditText input; ScrollView scroll;
    int white=Color.WHITE, muted=Color.rgb(175,175,195), panel=Color.rgb(20,18,30), purple=Color.rgb(139,92,246), cyan=Color.rgb(34,211,238);
    @Override public void onCreate(Bundle b){super.onCreate(b); build();}
    TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(18,14,18,14);return t;}
    void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(5,5,9));
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);head.setPadding(16,18,16,12);
        TextView back=text("‹",34,white);head.addView(back,new LinearLayout.LayoutParams(55,60));back.setOnClickListener(v->finish());
        TextView title=text("🤖 SHADOW IA",20,white);title.setTypeface(null,1);head.addView(title,new LinearLayout.LayoutParams(0,60,1));
        TextView sub=text("Especialista em treino • hipertrofia • força • resistência • hábitos",10,muted);sub.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);head.addView(sub,new LinearLayout.LayoutParams(230,60));
        root.addView(head);
        scroll=new ScrollView(this);messages=new LinearLayout(this);messages.setOrientation(LinearLayout.VERTICAL);messages.setPadding(12,8,12,12);scroll.addView(messages);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        HorizontalScrollView quickScroll=new HorizontalScrollView(this);quickScroll.setHorizontalScrollBarEnabled(false);LinearLayout quick=new LinearLayout(this);quick.setPadding(8,4,8,4);quick.setOrientation(LinearLayout.HORIZONTAL);addQuick(quick,"Hipertrofia");addQuick(quick,"Treino");addQuick(quick,"Dieta");addQuick(quick,"Resistência");addQuick(quick,"Recuperação");quickScroll.addView(quick,new HorizontalScrollView.LayoutParams(-2,58));root.addView(quickScroll,new LinearLayout.LayoutParams(-1,62));
        LinearLayout bar=new LinearLayout(this);bar.setPadding(10,8,10,12);input=new EditText(this);input.setHint("Pergunte ao SHADOW IA...");input.setTextColor(white);input.setHintTextColor(muted);input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);bar.addView(input,new LinearLayout.LayoutParams(0,58,1));Button send=new Button(this);send.setText("ENVIAR");send.setTextColor(white);bar.addView(send,new LinearLayout.LayoutParams(110,58));send.setOnClickListener(v->send());root.addView(bar);setContentView(root);
        addBot("Sou o SHADOW IA. Posso explicar hipertrofia, força, resistência, progressão de treino, recuperação, alimentação, hidratação, sono e organização dos hábitos. Faça sua pergunta.\n\n⚠️ Minhas respostas são educativas e não substituem avaliação de um profissional de saúde.");
    }
    void addQuick(LinearLayout row,String q){Button b=new Button(this);b.setText(q);b.setTextSize(9);b.setAllCaps(false);b.setMinWidth(130);b.setPadding(18,0,18,0);b.setOnClickListener(v->{input.setText(q+": ");input.setSelection(input.length());input.requestFocus();((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(input,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);});row.addView(b,new LinearLayout.LayoutParams(-2,52));}
    void send(){String q=input.getText().toString().trim();if(q.isEmpty())return;addUser(q);input.setText("");new Handler().postDelayed(()->addBot(answer(q)),220);}
    void bubble(String s,boolean user){TextView t=text(s,14,user?white:Color.rgb(235,235,245));t.setBackgroundColor(user?Color.rgb(42,34,65):panel);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.setMargins(user?70:0,7,user?0:70,7);messages.addView(t,lp);scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));}
    void addUser(String s){bubble("VOCÊ\n"+s,true);} void addBot(String s){bubble("SHADOW IA\n"+s,false);}
    String answer(String q){
        String x=q.toLowerCase(Locale.ROOT);
        if(x.contains("hipertrof")||x.contains("massa")||x.contains("crescer")) return "Para hipertrofia, pense em treino de resistência com boa técnica, volume adequado, progressão ao longo das semanas e recuperação. Trabalhe próximo da falha em parte das séries, mas não precisa levar todas à falha. Proteína suficiente, energia adequada, sono e consistência também importam. Se quiser, me diga seu treino atual e eu explico onde pode haver espaço para progressão.";
        if(x.contains("força")||x.contains("forca")) return "Para força, priorize exercícios compostos bem executados, séries com cargas desafiadoras, descanso suficiente e progressão planejada. A técnica vem antes de aumentar a carga.";
        if(x.contains("resist")||x.contains("cardio")||x.contains("corrida")) return "Para resistência, combine sessões fáceis com estímulos mais intensos de forma progressiva. Aumente duração ou intensidade gradualmente e respeite a recuperação. Posso ajudar a montar uma progressão de corrida ou cardio.";
        if(x.contains("dieta")||x.contains("comer")||x.contains("aliment")||x.contains("proteína")||x.contains("proteina")) return "Uma alimentação para ganho de massa costuma precisar de energia e proteína suficientes, além de carboidratos e gorduras em quantidades adequadas. Priorize alimentos variados e refeições que você consiga manter. Para metas específicas de calorias/macros, um nutricionista pode personalizar o plano.";
        if(x.contains("água")||x.contains("agua")||x.contains("hidrata")) return "Hidratação deve ser distribuída ao longo do dia e ajustada ao calor, suor e atividade. O SHADOW SYSTEM pode acompanhar sua meta em ml. Em treinos longos ou muito quentes, a reposição de líquidos e eletrólitos pode merecer atenção.";
        if(x.contains("sono")||x.contains("descanso")||x.contains("recuper")) return "Recuperação é parte do treino. Sono regular, dias de descanso quando necessários e controle do volume ajudam a sustentar desempenho e progresso. Dor forte, persistente ou sintomas fora do normal merecem avaliação profissional.";
        if(x.contains("treino")||x.contains("academia")||x.contains("série")||x.contains("serie")||x.contains("repet")) return "Um bom treino precisa de objetivo, exercícios adequados, técnica, volume e progressão. Registre cargas e repetições para enxergar evolução. Posso explicar divisão de treino, séries, repetições, descanso e progressão.";
        if(x.contains("emagrec")||x.contains("perder gordura")||x.contains("defini")) return "Para reduzir gordura, a alimentação precisa favorecer um déficit energético sustentável, enquanto o treino de força ajuda a preservar massa muscular. Evite estratégias extremas; consistência costuma vencer restrições agressivas.";
        if(x.contains("dor")||x.contains("lesão")||x.contains("lesao")||x.contains("remédio")||x.contains("remedio")) return "Posso explicar conceitos gerais, mas não diagnosticar lesões nem prescrever tratamento. Se houver dor forte, trauma, perda de força, dormência ou piora persistente, procure um profissional de saúde.";
        return "Boa pergunta. Posso te ajudar com hipertrofia, ganho de massa, força, resistência, cardio, treino, progressão, recuperação, alimentação, hidratação, sono e hábitos. Tente perguntar de forma específica, por exemplo: 'Como aumentar minhas repetições sem perder técnica?'";
    }
}
