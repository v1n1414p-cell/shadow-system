# SHADOW SYSTEM V8

Atualização: logo oficial no app e ícone, missões bônus realmente aleatórias por notificação sem reroll, recompensa fixada no momento do envio, registro de água em ml com +120/+250/+500 e valor personalizado, câmera/galeria para shape e dieta, pensamentos/humor, dicas, nickname e SHADOW IA.

No GitHub, mantenha este projeto dentro de `SHADOW_SYSTEM_ANDROID.zip` se o workflow externo usar esse nome.
