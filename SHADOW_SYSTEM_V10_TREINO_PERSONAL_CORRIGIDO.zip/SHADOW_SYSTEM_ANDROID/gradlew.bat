@echo off
REM SHADOW SYSTEM helper. The workflow installs Gradle explicitly.
gradle %*
