# SHADOW SYSTEM V3
Versão mobile com câmera, galeria, registro de dieta, pensamento/humor e missões bônus aleatórias.

### Novos recursos
- 📸 Foto do shape: câmera + armazenamento local e +10 XP
- 🖼 Galeria: escolher uma evolução existente e registrar +10 XP
- 🍽 Registro de dieta: salva a anotação localmente e dá +30 XP
- 🧠 Pensamento/humor: diário rápido local e +15 XP
- ⚡ Missão bônus: missão aleatória com recompensa de até +100 XP
- ⚖ Peso: registro local e +5 XP
- LEVEL UP automático e XP total

Compile pelo GitHub Actions usando `APK SHADOW SYSTEM V3`.
