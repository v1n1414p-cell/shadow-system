# SHADOW SYSTEM

PWA mobile-first para Android, com armazenamento local.

## Instalação no Android
1. Sirva esta pasta por HTTPS (por exemplo, GitHub Pages, Netlify ou Vercel).
2. Abra o endereço no Chrome Android.
3. Use o menu do navegador e escolha **Adicionar à tela inicial** / **Instalar app**.

O app funciona offline depois de carregado e salva o progresso no `localStorage`.

## Recursos
- XP, níveis e ranks E→S
- Missões diárias e especiais
- Streak
- Atributos
- Controle de peso
- Histórico
- Countdown para casamento
- Conquistas
- Missões personalizadas
- Interface dark/neon mobile-first
