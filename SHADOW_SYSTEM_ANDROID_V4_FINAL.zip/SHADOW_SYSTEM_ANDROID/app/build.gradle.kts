plugins { id("com.android.application") }

dependencies { implementation("androidx.core:core:1.15.0") }

android {
    namespace = "com.shadowsystem.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.shadowsystem.app.v3"
        minSdk = 23
        targetSdk = 33
        versionCode = 2
        versionName = "1.1.0"
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
}
