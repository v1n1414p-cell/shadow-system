# SHADOW SYSTEM V11

Versão mobile Android do SHADOW SYSTEM.

Inclui:
- logo SHADOW SYSTEM como identidade visual e ícone do app;
- tela inicial com splash/mensagem motivacional;
- navegação por abas e gesto de deslizar;
- missões diárias e missões bônus aleatórias por notificação/caixa dentro do sistema;
- missão bônus com recompensa fixa, sem reroll depois de enviada;
- missões com marcar/desmarcar para corrigir toque acidental;
- água com meta diária e adição por ml, incluindo atalhos +120 ml, +250 ml e +500 ml;
- câmera e galeria para evolução do shape;
- câmera e galeria para foto de refeição/dieta;
- guia de medidas de alimentos com medidas caseiras e equivalentes aproximados em gramas;
- ficha de treino com exercícios, séries, repetições e carga;
- SHADOW IA para dúvidas educativas sobre treino, hipertrofia, força, resistência, dieta, hidratação e recuperação;
- dicas de treino, alimentação e disciplina;
- dados principais salvos localmente no aparelho.

## Compilação pelo GitHub

1. Substitua o arquivo `SHADOW_SYSTEM_ANDROID.zip` do repositório pelo ZIP deste projeto.
2. Abra **Actions**.
3. Selecione **APK SHADOW SYSTEM V11 • AGUA + DIETA**.
4. Toque em **Run workflow**.
5. Quando terminar com **Success**, abra o artifact `SHADOW-SYSTEM-APK-V11`.
6. Extraia o `app-debug.apk` e instale pelo ZArchiver.
