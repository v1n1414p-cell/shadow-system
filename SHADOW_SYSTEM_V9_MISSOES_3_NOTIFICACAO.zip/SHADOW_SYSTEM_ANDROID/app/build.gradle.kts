plugins { id("com.android.application") }

android {
    namespace = "com.shadowsystem.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.shadowsystem.app.v5"
        minSdk = 23
        targetSdk = 35
        versionCode = 8
        versionName = "1.7.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
}

dependencies { implementation("androidx.core:core:1.15.0") }
