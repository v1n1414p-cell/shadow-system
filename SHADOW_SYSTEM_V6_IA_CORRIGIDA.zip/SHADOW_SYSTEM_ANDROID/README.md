# SHADOW SYSTEM

Versão 1.4.0. Inclui perfil/nickname, splash com logo, abas deslizáveis, evolução com câmera/galeria, dieta por foto, pensamentos/humor, missões marcáveis, missões bônus aleatórias com notificações, dicas de treino/dieta e meta de água com registro diário em ml.

Para o workflow existente que extrai `SHADOW_SYSTEM_ANDROID.zip`, mantenha este nome de arquivo no repositório.
