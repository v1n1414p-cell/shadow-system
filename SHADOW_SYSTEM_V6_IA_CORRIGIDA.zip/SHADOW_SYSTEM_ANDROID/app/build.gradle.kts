plugins { id("com.android.application") }

android {
    namespace = "com.shadowsystem.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.shadowsystem.app.v4"
        minSdk = 23
        targetSdk = 35
        versionCode = 6
        versionName = "1.5.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
}

dependencies { implementation("androidx.core:core:1.15.0") }
